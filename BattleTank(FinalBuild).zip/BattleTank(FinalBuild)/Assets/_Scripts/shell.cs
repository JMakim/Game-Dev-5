﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class shell : MonoBehaviour {

	// Use this for initialization
	void Start () {
		
	}
	
	// Update is called once per frame
	void Update () {
        this.gameObject.GetComponent<Rigidbody>().velocity = this.gameObject.transform.up * 5;
        Destroy(this.gameObject, 8.0f);
    }

    private void OnCollisionEnter(Collision collision)
    {
        Destroy(this.gameObject);
    }
}
